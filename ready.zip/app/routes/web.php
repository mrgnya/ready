<?php

Route::get('/', 'ViewController@showAll' );


Route::get('/content', function() {
        return view('list');
    });
Route::get('/content/films/{id}', 'ViewController@showId');





Route::get('/admin/add', function(){
    return view('add');
});
Route::post('/admin/add', 'ViewController@add');

Route::get('/admin', 'ViewController@showAllforAdmin');

Route::get('/admin/delete/{id}', 'ViewController@delete');

Route::post('/admin/edit/{id}', 'ViewController@edit');

Route::get('/admin/edit/{id}', 'ViewController@show');




